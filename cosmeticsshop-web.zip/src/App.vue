<template>
    <div id="app">
        <router-view />
    </div>
</template>

<style lang="stylus">
    #app
        font-family Avenir, Helvetica, Arial, sans-serif
        -webkit-font-smoothing antialiased
        -moz-osx-font-smoothing grayscale
        background-color #f3f4f6
        width 100%
        min-height 100vh
        overflow hidden
    body, p, li, ul
        margin 0
        padding 0
</style>
